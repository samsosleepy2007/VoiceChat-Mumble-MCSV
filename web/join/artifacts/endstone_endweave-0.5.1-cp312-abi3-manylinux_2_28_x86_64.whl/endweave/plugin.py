"""Endweave plugin - protocol translation for Bedrock Edition.

Endstone's events stand in for the netty pipeline ViaVersion installs itself
into. A received packet runs through the base protocol and then the
connection's serverbound translator on the lowest priority, so other plugins
read it as the server's version. A sent packet is carried towards the client's
version on the highest priority, once other plugins have read it as the
server's, as ViaVersion's encoder sits below the server's own. The login event
goes to the base protocol, and the connection is tracked from there until the
player quits.

Endstone stops passing events to a plugin as soon as it is disabled, so every
player whose connection is translated is kicked on disable, before a plugin
disabled after this one can send them a packet in the server's version.
ViaVersion's Bukkit platform kicks everyone on the next enable instead,
alongside ProtocolLib, as its handlers stay on the channel after a disable.

See Also:
    com.viaversion.viaversion.platform.ViaDecodeHandler
    com.viaversion.viaversion.platform.ViaEncodeHandler
"""

from pathlib import Path

from endstone.event import (
    EventPriority,
    PacketReceiveEvent,
    PacketSendEvent,
    PlayerJoinEvent,
    PlayerLoginEvent,
    PlayerQuitEvent,
    event_handler,
)
from endstone.plugin import Plugin

from ._pipeline import Action, TranslationError, Translator, packet_name
from .commands import CommandHandler
from .config import ConfigurationProvider, EndweaveConfig
from .connection import Connection, ConnectionManager
from .debug import DebugHandler, Direction, Packet, PacketType
from .metrics import EndweaveMetrics
from .protocol.base import BaseProtocol
from .protocol.version import get_protocol, get_protocols
from .update import send_update_message
from .util import translate_alternate_color_codes

_TRANSLATION_FAILED = "§cEndweave could not translate a packet for your version."


def _carries(protocol_version: int) -> bool:
    """Whether the engine translates a protocol version, the ones it routes as another included."""
    try:
        Translator(protocol_version, protocol_version)
    except ValueError:
        return False
    return True


def _packet_label(packet_id: int) -> str:
    """The packet's name as the debug filter spells it, or its ID where no version defines it."""
    name = packet_name(packet_id)
    return name.upper() if name is not None else str(packet_id)


class EndweavePlugin(Plugin):
    """Endstone plugin that enables protocol translation between Bedrock versions."""

    prefix = "Endweave"
    api_version = "0.11"
    commands = {
        "endweave": {
            "description": "Endweave plugin commands",
            "usages": [
                "/endweave",
                "/endweave list",
                "/endweave debug [clear|pre|post|add|remove] [packet: string]",
                "/endweave reload",
            ],
            "permissions": ["endweave.command"],
        }
    }
    permissions = {
        "endweave.admin": {
            "default": "op",
            "children": {
                "endweave.command": True,
                "endweave.command.list": True,
                "endweave.command.debug": True,
                "endweave.command.reload": True,
                "endweave.update": True,
            },
        },
    }

    def on_enable(self) -> None:
        self._configuration = EndweaveConfig(Path(self.data_folder) / "config.toml", self.logger)
        self._configuration_provider = ConfigurationProvider()
        self._configuration_provider.register(self._configuration)
        self._configuration_provider.reload_configs()

        server_protocol = self.server.protocol_version
        self.logger.info(f"Detected server protocol {server_protocol} (MC {self.server.minecraft_version})")

        carried = [version for version in get_protocols() if _carries(version.version)]
        self.logger.info(f"Translating between {', '.join(str(version) for version in carried)}")
        if not _carries(server_protocol):
            self.logger.warning("Endweave does not have any compatible versions for this server version!")
            self.logger.warning(
                f"Every packet passes through untouched until Endweave supports protocol {server_protocol}."
            )

        self._connection_manager = ConnectionManager(get_protocol(server_protocol))
        self._base_protocol = BaseProtocol(self._connection_manager, self._configuration, self.logger)

        self.register_events(self)
        self._debug_handler = DebugHandler(
            self.logger,
            log_conversion_warnings=self._configuration.log_other_conversion_warnings,
            max_error_length=self._configuration.max_error_length,
        )
        self.get_command("endweave").executor = CommandHandler(self._debug_handler, self._configuration_provider)

        # bStats metrics (https://bstats.org/plugin/bukkit/Endweave/30345)
        self._metrics = EndweaveMetrics(self, service_id=30345)

        if self._configuration.check_for_updates:
            send_update_message(self)

    def on_disable(self) -> None:
        """Stop the metrics submitter and kick every player whose connection is translated.

        Safe to call when ``on_enable`` did not finish.

        See Also:
            com.viaversion.viaversion.ViaVersionPlugin#onReload
        """
        metrics: EndweaveMetrics | None = getattr(self, "_metrics", None)
        if metrics is not None:
            metrics.shutdown()  # type: ignore[no-untyped-call]

        connection_manager: ConnectionManager | None = getattr(self, "_connection_manager", None)
        if connection_manager is None:
            return

        message = translate_alternate_color_codes(self._configuration.reload_disconnect_message)
        for connection in connection_manager.connections.values():
            if connection.clientbound is not None and connection.clientbound.actions:
                connection.disconnect(message)

    @event_handler(priority=EventPriority.LOWEST)
    def on_packet_receive(self, event: PacketReceiveEvent) -> None:
        connection = self._base_protocol.transform_serverbound(event)
        if connection is not None:
            self._translate(connection, event, Direction.SERVERBOUND)

    @event_handler(priority=EventPriority.HIGHEST, ignore_cancelled=True)
    def on_packet_send(self, event: PacketSendEvent) -> None:
        connection = self._connection_manager.get_connection(str(event.address))
        if connection is not None:
            self._translate(connection, event, Direction.CLIENTBOUND)

    def _translate(
        self,
        connection: Connection,
        event: PacketReceiveEvent | PacketSendEvent,
        direction: Direction,
    ) -> None:
        """Carry one packet across, where the connection has a translator that names its ID.

        Args:
            connection: The peer the packet belongs to.
            event: The packet event, whose payload is replaced in place.
            direction: Direction the packet travels in.
        """
        translator = connection.serverbound if direction is Direction.SERVERBOUND else connection.clientbound
        if translator is None:
            return

        packet_id = event.packet_id
        action = translator.actions.get(packet_id)
        if action is None:
            return

        debug = self._debug_handler
        label: str | int = packet_id
        logged = False
        if debug.enabled:
            name = packet_name(packet_id)
            packet_type = PacketType(packet_id, name.upper(), direction) if name is not None else None
            logged = debug.should_log(Packet(packet_id, packet_type), direction)
            if packet_type is not None:
                label = packet_type.name

        if action is Action.CANCEL:
            if logged:
                self.logger.info(f"[{direction.value}] {label} dropped, the other side has no such packet")
            event.cancel()
            return

        if logged and debug.log_pre_packet_transform:
            self.logger.info(f"[{direction.value}] {label} in: {event.payload.hex()}")

        try:
            payload = translator.translate(packet_id, event.payload)
        except TranslationError as error:
            debug.log_translation_failure(
                f"Failed to translate {direction.value} packet {_packet_label(packet_id)} "
                f"at {error.stage} for {connection.address} "
                f"({connection.protocol_version} against {connection.server_protocol_version})",
                error,
            )
            connection.serverbound = None
            connection.clientbound = None
            event.cancel()
            connection.disconnect(_TRANSLATION_FAILED)
            return

        if payload is None:
            if logged:
                self.logger.info(f"[{direction.value}] {label} refused by a transform")
            elif debug.log_conversion_warnings:
                self.logger.warning(
                    f"Dropped {direction.value} packet {_packet_label(packet_id)} for "
                    f"{connection.address}, a transform could not carry it to the other version"
                )
            event.cancel()
            return

        if logged and debug.log_post_packet_transform:
            self.logger.info(f"[{direction.value}] {label} out: {payload.hex()}")

        event.payload = payload

    @event_handler
    def on_player_login(self, event: PlayerLoginEvent) -> None:
        self._base_protocol.on_login(event)

    @event_handler
    def on_player_join(self, event: PlayerJoinEvent) -> None:
        player = event.player
        if player.has_permission("endweave.update") and self._configuration.check_for_updates:
            send_update_message(self, player)

    @event_handler
    def on_player_quit(self, event: PlayerQuitEvent) -> None:
        player = event.player
        connection = self._connection_manager.get_connection(str(player.address))
        if connection is None or connection.player is None or connection.player.unique_id != player.unique_id:
            return

        self._connection_manager.on_disconnect(connection)
