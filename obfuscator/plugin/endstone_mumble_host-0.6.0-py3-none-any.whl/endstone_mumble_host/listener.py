# Copyright SamSoSleepy. Protected distribution; see packaged license.
def _p06981f1b9e0b9d6240b0_load():
    import base64, zlib, hashlib
    k = b'T\x1b\xac{Uv}c\xab\xba\xf3\xeaU\x82`-\x8e\xcco5fF\x1b:\x93i\x0fk\x95\xb5\xf8R'
    p = base64.b85decode(b'EWtVJ1U<e}zdtMyer&rxW`;-yu*BFc(k)8#(Dp-)n4_4|94yNm#2}?hcPbetY0%M5h$D7{y<a5SKfW}%*0f`_rcC;1TjyAM#dw7LpT6rNUdAgd9Z5Q$0n_9q(m3@G3tCEOv3IcGsA69b-BxE_d<NF1q;oun#Lj3RKesD<0PC&2vlCqGY#-$6z&0km7qCH7J-I2O+u$~n3CwtL`umR5dBZ1yo~Gg5w#E;646gzio%~12z-Xp8UeJN3(vKLgrqx5)V^{&=fBy{|ffXe4)$aGZ8VG%qM<nX7y6u5cgrOqY35ErZ%rm#vTUzm*jW!6E$~th#q2sKaO2_a')
    s = zlib.decompress(bytes(x ^ k[i % len(k)] for i, x in enumerate(p)))
    if hashlib.sha256(s).hexdigest() != 'ca4030190f5683fa94d7b720ac9eb3fc9fe5f34d596614d892ed6458900204f9':
        raise ImportError("Protected module integrity check failed")
    exec(compile(s, __file__, "exec", dont_inherit=True), globals())
_p06981f1b9e0b9d6240b0_load()
del _p06981f1b9e0b9d6240b0_load
