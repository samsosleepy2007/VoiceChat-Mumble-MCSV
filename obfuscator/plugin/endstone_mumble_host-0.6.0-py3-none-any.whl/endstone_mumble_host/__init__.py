# Copyright SamSoSleepy. Protected distribution; see packaged license.
def _p096341417d821a10909b_load():
    import base64, zlib, hashlib
    k = b'x4Ip\xb7\x85m\x81P\x85\xc1\xc4\x1d\xb6\xb4\x1a\xef\xa7R0\x96\x89{\xfd\xc3X\xac\xe8\xd2\xdc\x16\xe5'
    p = base64.b85decode(b'0Pa+|hKsMENP`g>PRj2)KB4B}q%pvS!8;)!U9}uwC|skR8Y_al^3?{1KCR6t0{Lu}#>*06QWMxLN+NQ9U~icbH;814s+960s2AfZD-FQiI3$C@M0H9x4Kj*~6h2o4!(h<MzvhYE%2WZlq(7i1%rIV<')
    s = zlib.decompress(bytes(x ^ k[i % len(k)] for i, x in enumerate(p)))
    if hashlib.sha256(s).hexdigest() != '3e36c0f05dfd5c55be1ca7c2ce7d3d0b30ee36614b35a52e2aa8a23b22b9567b':
        raise ImportError("Protected module integrity check failed")
    exec(compile(s, __file__, "exec", dont_inherit=True), globals())
_p096341417d821a10909b_load()
del _p096341417d821a10909b_load
