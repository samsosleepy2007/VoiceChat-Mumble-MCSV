# Copyright SamSoSleepy. Protected distribution; see packaged license.
def _pa7cbe895fb0bb220bd96_load():
    import base64, zlib, hashlib
    k = b'\xfd\x96}\xfb9\r\x07\x14\x90y\xef\x9b\xd06u*?\xbe\xd3ub\xcd\x86\xed\x1c\x15\xcf\xda\xc4\\\xf2\x02'
    p = base64.b85decode(b'g-r0NWJ1I=gaiOIXb9L2;@qF14+ILLB913Pm0lmmY^N1_SKxW61jAVXTQ54cL~t?-Lt$U<xwkz}ffloDw)H^Elz?DLij@7qV)5z8L(lw;Pb%@6tErdf1Xhk$*V-;6L3wUYQ*MLX$UQ(}GKG;7XDc8rXh*i|SrfV@%8!wu$L^Gb)Xg@KHgDUqOjcc-nVl5T>*D)z%k-t~OH^@Z3)8|c*<0c?S_2*ReP?SqLeWcGq!B2$fGO9B{KHyPsaDfE<U)P4ksh{IJ9EovEY&db-$ym3`BEN^F$dqBWo%E}9Vm|J|9VWuGu3e9oN8?6SQIuuEi>L~#v-X&D-<8A*1~I2c*8s_n$KY<e+X2h$s^h^4V(<@2^w9?M29}FA<QWGC^>KN6Ah*L5`JudX+0zBmV1W{XGM*wMXb`*;_%~L2+`Sf@E$xiMhBjnfuTt=YyQ;oNo-DV3Ut)p3la+)j!4bGN(juW1vc)~!_-#)y8J8_Ec2%H59~*4')
    s = zlib.decompress(bytes(x ^ k[i % len(k)] for i, x in enumerate(p)))
    if hashlib.sha256(s).hexdigest() != 'eac95c19452bc9d10953a9128269f86cfc163b1f222ce73f50a00dea204a8dd2':
        raise ImportError("Protected module integrity check failed")
    exec(compile(s, __file__, "exec", dont_inherit=True), globals())
_pa7cbe895fb0bb220bd96_load()
del _pa7cbe895fb0bb220bd96_load
