# Copyright SamSoSleepy. Protected distribution; see packaged license.
def _pac6990386b06d5aa14bb_load():
    import base64, zlib, hashlib
    k = b'\x12\x8c{f\x16TM\x96\xfaQ\xee\xc0q\x1eh\xa8\x96\xbe\xc4\xa3\x7f\xb7\xd4\xfb\\\xdf\x8fC\xf8\xe7\x84\xac'
    p = base64.b85decode(b'YF6$rO((9R?k^#4VPi038fjnX46^5se7YANZf5dKvw>x!fCnJ^GYOnqA>_A_1S33g#}iG8cqC_^MhKYYL#k<l?FHjxcB{~$I5b)<o>_*ny0b&ZWBN`f#s~|_f%yb<m|au~RfZ;mTTu%lXT)O*yU$+*9w?_#;XS5m!w(kSH(3eZOT<MejMCaAW?+S^CCOKOpH>W&E()@+(_j1nYVSal;?_g46~|_36>pRbNJJe^3^H8G12O~KBGo{fKhu2VDu`(toW56;4FK;~xkR?g0UW%--(6Yi)<oUB@=ak05Vm!%+{YHyFnb4L-{)D`@1wDiSNylLpLvJrDZ_W1DhahVyQmY57U5t+giZ^>kv4G#at9g)?-#+XK3!Bv4s)YKtGift1<nQ3!s*25bq=UfXdjNWv)lK%IWBOLMZu_mZ2crrs3`CytJGy8jI%Bl<r6V4{0J{?G6AcLouEj61CAaZmhe#2K`L3=@mu3Q>yv#MEfb@T>m#Kl8YPdMnt`4`Y&(Ms`PBw#HXyH%yR7D(<~Rn*u_6Y_KxS<_>fqO*&mO9SYVfm6244LRa>n9i>@8*LZe-D~JfqLis&G>{+!}r*h_h@kTh*1WonrX?N&6N6{tM2KqJgd3Vm$rlCGxEQMK{Y=R?RRB%XU`a|AOx@%+eVZ#`Uwo?oR;zXnd3QYvo0^2^GSbpfk*&BL&;Boj66A;S+g@?%ISY^ab|w`p3|zYgeX<!iVTgPi*r?!dV!|OMNAI@+Kj`!3W9$BlMQ&onmB9klJo)KYq-OmfZQBbqfMgrxhs8E!Y+owZjLerGv9kUKiKvzAvuCov6M;iL`01a)ka962)C)4rIUap@2&FKUNyUk5+Xw>C=P61{B^-WL3am1Boa{uj8nGaXRk$14H1u8BtcNKw<4UfBDM>WmBj+$T^P=$h3QQgqTH95jDKI%$v2m81;8y^vWRG_lY3_7^bc>2qkZ<uQWxneB18^g{bXQ6d{`9%vN%i%fzG!bEwCSpqcsx!{DIoWm<4X#gj#xDXO_`KYl@wh-R<K{M2`K2<Jjwse#Eq>`8|7LAd-VE+jZUCGXX~c)&q4f8pdC9Sc#5g}o{$8%sA?e`o@`%c~19XL)LbV4f)VpknmwEe^Zgd|D}I+pXY!`34DUjXlc#NYlm6luS3GAF|v~GiD6cxjDs@S<%^bRd26z^uEB<^ZkuRnoS*-=G60{#PloHo3)6fv(!W(1f9~^I~urxqaL2`(gqyFK}j)En@k(<sN0a;RWK+t2_1kgBw9*{bbXymGH!^+&wLQ=;ACFezt}_erP$xO3Z0ljn2(k;ykurY_2ZP6OQo1>')
    s = zlib.decompress(bytes(x ^ k[i % len(k)] for i, x in enumerate(p)))
    if hashlib.sha256(s).hexdigest() != 'bd38a6579dbb5593f828720cf4cb832c78290687293a3fbf1bb7c25fa52ac03a':
        raise ImportError("Protected module integrity check failed")
    exec(compile(s, __file__, "exec", dont_inherit=True), globals())
_pac6990386b06d5aa14bb_load()
del _pac6990386b06d5aa14bb_load
