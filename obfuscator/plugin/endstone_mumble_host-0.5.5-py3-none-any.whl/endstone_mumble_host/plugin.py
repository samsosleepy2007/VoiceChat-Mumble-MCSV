from __future__ import annotations
import json
import os
from concurrent.futures import ThreadPoolExecutor
import math
import threading
import time
from typing import Any
from endstone import Player
from endstone.command import Command, CommandSender
from endstone.form import ActionForm
from endstone.plugin import Plugin
from .host import MumbleRuntimeHost
from .listener import MumbleHostListener
from .local_state import LocalStateSink
from .model import PlayerState
ATTENUATION_LEVELS: dict[int, str] = {0: 'ปิด', 1: 'เบา', 2: 'ปกติ', 3: 'แรง', 4: 'แรงมาก'}

class MumbleHost(Plugin):
    prefix = 'MumbleHost'
    version = '0.5.5'
    api_version = '0.11'
    description = 'Unified MCSV Mumble server + Item Mic proximity + SleepyPhone call routing'
    authors = ['SamSoSleepy']
    commands = {'vcb': {'description': 'Open MumbleHost proximity status', 'usages': ['/vcb [action: string]'], 'permissions': ['mumble_host.command.user']}}
    permissions = {'mumble_host.command.user': {'description': 'Use MumbleHost status UI.', 'default': True}, 'mumble_host.command.admin': {'description': 'Administer the local Mumble host.', 'default': 'op'}}

    def __init__(self) -> None:
        super().__init__()
        self._states: dict[str, PlayerState] = {}
        self._bindings: dict[str, dict[str, Any]] = {}
        self._calls: dict[str, dict[str, Any]] = {}
        self._binding_writer: ThreadPoolExecutor | None = None
        self._host: MumbleRuntimeHost | None = None
        self._state_sink: LocalStateSink | None = None
        self._interval_ticks = 2
        self._position_epsilon = 0.05
        self._rotation_epsilon = 1.0
        self._heartbeat_ticks = 300
        self._heartbeat_accumulator = 0
        self._default_range = 30
        self._max_range = 150
        self._default_attenuation_level = 3
        self._mumble_port = 18655
        self._mumble_users = 20
        self._last_host_running = False

    def on_enable(self) -> None:
        if self._binding_writer is None:
            self._binding_writer = ThreadPoolExecutor(max_workers=1, thread_name_prefix='SleepyBindings')
        self._install_performance_monitor()
        self.save_default_config()
        self._load_settings()
        self._load_bindings()
        self.register_events(MumbleHostListener(self))
        if self._state_sink is not None:
            self._state_sink.start()
        if self._host is not None:
            self._host.start()
        self.server.scheduler.run_task(self, self._tracking_tick, delay=0, period=self._interval_ticks)
        self.logger.info(f'MumbleHost Unified v{self.version} enabled; mumble_port={self._mumble_port} tracking={self._interval_ticks} ticks default_range={self._default_range} max_range={self._max_range} attenuation={self._default_attenuation_level}')
        self.logger.info('Unified MCSV mode: Item Mic state goes directly to local proximity feed; no Android/mobile bridge is used.')
        self.logger.info(f'Enabled mumble_host v{self.version}')

    def on_disable(self) -> None:
        try:
            self.server.scheduler.cancel_tasks(self)
        except Exception:
            pass
        writer = self._binding_writer
        self._binding_writer = None
        if writer is not None:
            try:
                writer.shutdown(wait=True, cancel_futures=False)
            except Exception as exc:
                self.logger.warning(f'Could not finish binding writer: {exc}')
        sink = self._state_sink
        self._state_sink = None
        if sink is not None:
            sink.stop()
        host = self._host
        self._host = None
        if host is not None:
            host.stop()
        self._save_bindings()
        self._states.clear()
        self._calls.clear()
        self.logger.info('MumbleHost Unified disabled')

    def _load_settings(self) -> None:
        _o6 = self.config.get('tracking', {})
        _o3 = self.config.get('mumble', {})
        _o1 = self.config.get('local_state', {})
        _o7 = self.config.get('voice', {})
        self._interval_ticks = self._bounded_int(_o6.get('interval_ticks', 2), 1, 20, 2)
        self._position_epsilon = self._bounded_float(_o6.get('position_epsilon', 0.05), 0.001, 10.0, 0.05)
        self._rotation_epsilon = self._bounded_float(_o6.get('rotation_epsilon', 1.0), 0.01, 180.0, 1.0)
        _o0 = self._bounded_int(_o6.get('heartbeat_seconds', 15), 2, 3600, 15)
        self._heartbeat_ticks = _o0 * 20
        self._default_range = self._bounded_int(_o7.get('default_range', 30), 1, 1000, 30)
        self._max_range = self._bounded_int(_o7.get('max_range', 150), self._default_range, 1000, 150)
        self._default_attenuation_level = self._bounded_int(_o7.get('default_attenuation_level', 3), 0, 4, 3)
        self._mumble_port = self._bounded_int(_o3.get('port', 18655), 1, 65535, 18655)
        self._mumble_users = self._bounded_int(_o3.get('users', 20), 1, 500, 20)
        _o4 = str(_o1.get('host', '127.0.0.1')).strip()
        if _o4 not in {'127.0.0.1', 'localhost'}:
            self.logger.warning('local_state.host forced to 127.0.0.1 in unified mode')
            _o4 = '127.0.0.1'
        _o5 = self._bounded_int(_o1.get('port', 47855), 1, 65535, 47855)
        _o2 = self._bounded_int(_o1.get('max_queue', 4096), 128, 65536, 4096)
        self._host = MumbleRuntimeHost(self.logger, self.data_folder, port=self._mumble_port, users=self._mumble_users)
        self._state_sink = LocalStateSink(self.logger, host=_o4, port=_o5, max_queue=_o2)

    def _load_bindings(self) -> None:
        path = self.data_folder / 'bindings.json'
        if not path.is_file():
            self._bindings = {}
            return
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
            self._bindings = data if isinstance(data, dict) else {}
            changed = False
            for key, raw in list(self._bindings.items()):
                if not isinstance(raw, dict):
                    self._bindings.pop(key, None)
                    changed = True
                    continue
                binding = dict(raw)
                if 'mumble_name' in binding:
                    binding.pop('mumble_name', None)
                    changed = True
                if 'attenuation_level' in binding:
                    binding.pop('attenuation_level', None)
                    changed = True
                if binding:
                    self._bindings[key] = binding
                else:
                    self._bindings.pop(key, None)
            if changed:
                self._save_bindings()
        except Exception as exc:
            self._bindings = {}
            self.logger.warning(f'Could not load bindings.json: {type(exc).__name__}: {exc}')

    def _save_bindings(self) -> None:
        payload = json.dumps(self._bindings, ensure_ascii=False, indent=2)
        path = self.data_folder / 'bindings.json'
        writer = self._binding_writer
        if writer is None:
            self.logger.warning('Binding update ignored: plugin is disabled')
            return
        try:
            writer.submit(self._write_bindings_file, path, payload)
        except RuntimeError as exc:
            self.logger.warning(f'Could not queue range storage update: {exc}')

    def _write_bindings_file(self, path: Any, payload: str) -> None:
        try:
            temporary = path.with_suffix('.json.tmp')
            temporary.write_text(payload, encoding='utf-8')
            os.replace(temporary, path)
        except Exception as exc:
            self.logger.warning(f'Could not save bindings.json: {type(exc).__name__}: {exc}')

    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        if command.name != 'vcb':
            return False
        if args and args[0].lower() == 'perf':
            if isinstance(sender, Player) and (not sender.has_permission('mumble_host.command.admin')):
                sender.send_error_message('You do not have permission.')
                return True
            for _o0 in self._performance_lines():
                sender.send_message(_o0)
            return True
        if isinstance(sender, Player):
            self._show_main_menu(sender)
        else:
            sender.send_message(f'MumbleHost Unified v{self.version}: host={self._host_state_label()}, port={self._mumble_port}, tracked={len(self._states)}, attenuation={self._default_attenuation_level}')
        return True

    def _install_performance_monitor(self) -> None:
        self._perf_stats = {}
        self._perf_started = time.perf_counter()
        self._perf_last_log = self._perf_started
        if getattr(self, '_perf_installed', False):
            return
        self._perf_installed = True
        for method, label in (('_process_addon_controls', 'range_controls'), ('_snapshot_if_valid', 'player_snapshot'), ('_sync_call_sessions', 'phone_calls'), ('_tracking_tick', 'tracking_total')):
            original = getattr(self, method)

            def measured(*args, _original=original, _label=label, **kwargs):
                wall_start = time.perf_counter()
                cpu_start = time.thread_time()
                try:
                    return _original(*args, **kwargs)
                finally:
                    cpu_ms = (time.thread_time() - cpu_start) * 1000.0
                    wall_ms = (time.perf_counter() - wall_start) * 1000.0
                    row = self._perf_stats.setdefault(_label, [0, 0.0, 0.0, 0.0])
                    row[0] += 1
                    row[1] += cpu_ms
                    row[2] += wall_ms
                    row[3] = max(row[3], wall_ms)
                    if _label == 'tracking_total' and time.perf_counter() - self._perf_last_log >= 30:
                        for line in self._performance_lines():
                            self.logger.info(line)
                        self._perf_stats.clear()
                        self._perf_started = time.perf_counter()
                        self._perf_last_log = self._perf_started
            setattr(self, method, measured)

    def _performance_lines(self) -> list[str]:
        window = max(0.001, time.perf_counter() - self._perf_started)
        lines = [f'VC_PERF window_s={window:.1f} scope=MumbleHost-main-thread cpu=thread-time wall=elapsed']
        rows = sorted(((name, row) for name, row in self._perf_stats.items() if name != 'tracking_total'), key=lambda entry: entry[1][1], reverse=True)
        if 'tracking_total' in self._perf_stats:
            rows.append(('tracking_total', self._perf_stats['tracking_total']))
        for name, (count, cpu_ms, wall_ms, max_ms) in rows:
            lines.append(f'VC_PERF part={name} calls={count} cpu_ms={cpu_ms:.3f} wall_ms={wall_ms:.3f} avg_wall_ms={wall_ms / max(1, count):.3f} max_wall_ms={max_ms:.3f} one_core_pct={cpu_ms / (window * 10):.3f}')
        return lines

    def _host_state_label(self) -> str:
        _o0 = self._host
        return _o0.status_line() if _o0 is not None else 'offline'

    def _show_main_menu(self, player: Player) -> None:
        _o2 = self._player_key(player)
        _o0 = self._bindings.get(_o2, {})
        _o4 = int(_o0.get('range') or self._default_range)
        _o3 = 'ON' if self._voice_enabled_for(player) else 'OFF'
        _o1 = ActionForm(title='MumbleHost • MCSV', content=f'Mumble Host: {self._host_state_label()}\nMumble Port: {self._mumble_port}\nMumble Username: {player.name}\nMic: {_o3}\nVoice Range: {_o4} blocks\nDistance Volume: {ATTENUATION_LEVELS[self._default_attenuation_level]} (level {self._default_attenuation_level})\nTracked: {len(self._states)}')
        _o1.add_button('ซิงก์ข้อมูลของฉัน', on_click=self._sync_player_from_ui)
        if player.has_permission('mumble_host.command.admin'):
            _o1.add_button('รีสตาร์ท Mumble Host', on_click=self._restart_host_from_ui)
        player.send_form(_o1)

    def _sync_player_from_ui(self, player: Player) -> None:
        self._publish_addon_range_tags(player)
        self._publish_addon_attenuation_tags(player)
        self._broadcast_current_player(player)
        player.send_message('MumbleHost: synced Item Mic state.')
        self._show_main_menu(player)

    def _restart_host_from_ui(self, player: Player) -> None:
        if not player.has_permission('mumble_host.command.admin'):
            player.send_error_message('You do not have permission.')
            return
        _o0 = self._host
        if _o0 is None:
            player.send_error_message('Mumble host is unavailable.')
            return
        self._last_host_running = False
        threading.Thread(target=_o0.restart, name='MumbleHost-Restart', daemon=True).start()
        player.send_message('MumbleHost: restarting local Mumble server.')
        self._show_main_menu(player)

    def handle_player_join(self, player: Player) -> None:
        self._publish_addon_range_tags(player)
        self._publish_addon_attenuation_tags(player)
        _o0 = self._snapshot_if_valid(player)
        if _o0 is None:
            return
        self._states[self._player_key(player)] = _o0
        self._send_state(_o0)

    def handle_player_quit(self, player: Player) -> None:
        _o0 = self._player_key(player)
        _o2 = self._states.pop(_o0, None)
        _o1 = _o2.name if _o2 is not None else str(player.name)
        self._state_send({'type': 'player_leave', 'name': _o1, 'xuid': str(player.xuid or ''), 'uuid': str(player.unique_id), 'mumbleName': _o1})

    def _tracking_tick(self) -> None:
        _o10 = time.perf_counter()
        _o1: set[str] = set()
        for _o5 in self.server.online_players:
            _o4 = self._player_key(_o5)
            _o1.add(_o4)
            _o0 = self._process_addon_controls(_o5)
            _o9 = self._snapshot_if_valid(_o5)
            if _o9 is None:
                _o6 = self._states.pop(_o4, None)
                if _o6 is not None:
                    self._state_send({'type': 'player_leave', 'name': _o6.name, 'xuid': _o6.xuid, 'uuid': _o6.uuid, 'mumbleName': _o6.name})
                    self.logger.warning(f'STATE_INVALID player={_o5.name} action=fail-closed')
                continue
            _o6 = self._states.get(_o4)
            if _o6 is None or _o9.voice_enabled != _o6.voice_enabled:
                self.logger.info(f'MIC_STATE player={_o9.name} endstone={('ON' if _o9.voice_enabled else 'OFF')}')
            if _o0 or _o6 is None or _o9.changed_from(_o6, self._position_epsilon, self._rotation_epsilon):
                self._states[_o4] = _o9
                self._send_state(_o9)
        for _o8 in set(self._states).difference(_o1):
            _o7 = self._states.pop(_o8)
            self._state_send({'type': 'player_leave', 'name': _o7.name, 'xuid': _o7.xuid, 'uuid': _o7.uuid, 'mumbleName': _o7.name})
        self._sync_call_sessions()
        _o3 = self._host.running if self._host is not None else False
        if _o3 and (not self._last_host_running):
            self._send_full_snapshot()
            self.logger.info(f'Local proximity state synced; tracked={len(self._states)}')
        self._last_host_running = _o3
        self._heartbeat_accumulator += self._interval_ticks
        if self._heartbeat_accumulator >= self._heartbeat_ticks:
            self._heartbeat_accumulator = 0
            self._state_send({'type': 'heartbeat', 'online': len(_o1), 'tracked': len(self._states), 'ts': int(time.time() * 1000)})
        _o2 = (time.perf_counter() - _o10) * 1000.0
        if _o2 > 35.0:
            self.logger.warning(f'TRACKING_SLOW duration_ms={_o2:.2f} players={len(_o1)} calls={len(self._calls)}')

    def _send_full_snapshot(self) -> None:
        self._state_send({'type': 'sync_begin', 'count': len(self._states)})
        for _o1, _o2 in self._states.items():
            self._state_send(self._state_message(_o1, _o2))
        for _o0 in self._calls.values():
            self._state_send(_o0)
        self._state_send({'type': 'sync_end', 'count': len(self._states)})

    def _collect_call_sessions(self) -> dict[str, dict[str, Any]]:
        prefix = 'vcmumble.call.active.'
        pending: dict[str, dict[str, tuple[str, bool]]] = {}
        for player in self.server.online_players:
            try:
                tags = list(player.scoreboard_tags)
            except Exception:
                continue
            for tag in tags:
                if not tag.startswith(prefix):
                    continue
                payload = tag[len(prefix):]
                parts = payload.rsplit('.', 2)
                if len(parts) != 3:
                    continue
                call_id, role, speaker_raw = parts
                call_id = call_id.strip()
                role = role.strip().lower()
                if not call_id or role not in {'a', 'b'}:
                    continue
                speaker = speaker_raw.strip() == '1'
                pending.setdefault(call_id, {})[role] = (str(player.name), speaker)
        sessions: dict[str, dict[str, Any]] = {}
        for call_id, roles in pending.items():
            party_a = roles.get('a')
            party_b = roles.get('b')
            if party_a is None or party_b is None:
                continue
            if party_a[0].casefold() == party_b[0].casefold():
                continue
            sessions[call_id] = {'type': 'call_state', 'callId': call_id, 'partyA': party_a[0], 'partyB': party_b[0], 'speakerA': bool(party_a[1]), 'speakerB': bool(party_b[1])}
        return sessions

    def _sync_call_sessions(self) -> None:
        _o1 = self._collect_call_sessions()
        for _o0, _o2 in _o1.items():
            _o3 = self._calls.get(_o0)
            if _o3 != _o2:
                self._state_send(_o2)
        for _o0 in set(self._calls).difference(_o1):
            self._state_send({'type': 'call_end', 'callId': _o0})
        self._calls = _o1

    def _broadcast_current_player(self, player: Player) -> None:
        _o1 = self._snapshot_if_valid(player)
        if _o1 is None:
            return
        _o0 = self._player_key(player)
        self._states[_o0] = _o1
        self._send_state(_o1)

    def _send_state(self, state: PlayerState) -> None:
        _o0 = state.xuid if state.xuid else state.uuid
        self._state_send(self._state_message(_o0, state))

    def _state_message(self, key: str, state: PlayerState) -> dict[str, Any]:
        _o0 = self._bindings.get(key, {})
        return {'type': 'player_state', 'name': state.name, 'xuid': state.xuid, 'uuid': state.uuid, 'mumbleName': state.name, 'dimension': state.dimension, 'x': state.x, 'y': state.y, 'z': state.z, 'yaw': state.yaw, 'pitch': state.pitch, 'voiceRange': 4 if state.phone_voice_enabled else int(_o0.get('range') or self._default_range), 'voiceEnabled': bool(state.voice_enabled), 'attenuationLevel': self._default_attenuation_level}

    def _state_send(self, message: dict[str, Any]) -> bool:
        _o0 = self._state_sink
        return _o0.send(message) if _o0 is not None else False

    @staticmethod
    def _player_key(player: Player) -> str:
        return str(player.xuid or '') or str(player.unique_id)

    def _snapshot_if_valid(self, player: Player) -> PlayerState | None:
        try:
            loc = player.location
            state = PlayerState(name=str(player.name), xuid=str(player.xuid or ''), uuid=str(player.unique_id), dimension=str(player.dimension.name), x=float(loc.x), y=float(loc.y), z=float(loc.z), yaw=float(loc.yaw), pitch=float(loc.pitch), voice_enabled=self._voice_enabled_for(player), phone_voice_enabled='vcmumble.call.mic' in player.scoreboard_tags)
            values = (state.x, state.y, state.z, state.yaw, state.pitch)
            if not all((math.isfinite(v) for v in values)):
                return None
            if state.y < -4096.0 or state.y > 4096.0:
                return None
            if abs(state.x) > 30000000 or abs(state.z) > 30000000:
                return None
            return state if state.dimension else None
        except Exception:
            return None

    def _process_addon_controls(self, player: Player) -> bool:
        try:
            tags = list(player.scoreboard_tags)
        except Exception:
            return False
        key = self._player_key(player)
        binding = dict(self._bindings.get(key, {}))
        current_range = int(binding.get('range') or self._default_range)
        maximum = 1000 if self._is_operator(player) else self._max_range
        changed = False
        for tag in tags:
            if tag.startswith('vcmumble.vr.sync.'):
                request_id = tag[len('vcmumble.vr.sync.'):]
                self._remove_player_tag(player, tag)
                self._publish_addon_range_tags(player, current_range, maximum)
                if request_id:
                    self._add_player_tag(player, f'vcmumble.vr.ack.{request_id}.ok.{current_range}')
                continue
            if tag.startswith('vcmumble.vr.request.'):
                payload = tag[len('vcmumble.vr.request.'):]
                request_id, separator, raw_value = payload.rpartition('.')
                started_at = time.perf_counter()
                self.logger.info(f'RANGE_BEGIN player={player.name} id={request_id}')
                self._remove_player_tag(player, tag)
                removed_at = time.perf_counter()
                status = 'error'
                try:
                    requested = int(raw_value) if separator else 0
                except ValueError:
                    requested = 0
                if request_id and 1 <= requested <= maximum:
                    status = 'ok'
                    if requested != current_range:
                        binding['range'] = requested
                        self._bindings[key] = binding
                        self._save_bindings()
                        current_range = requested
                        changed = True
                stored_at = time.perf_counter()
                self._publish_addon_range_tags(player, current_range, maximum)
                published_at = time.perf_counter()
                if request_id:
                    self._add_player_tag(player, f'vcmumble.vr.ack.{request_id}.{status}.{current_range}')
                done_at = time.perf_counter()
                elapsed_ms = (done_at - started_at) * 1000.0
                self.logger.info(f'RANGE_ACK player={player.name} id={request_id} requested={requested} actual={current_range} status={status} duration_ms={elapsed_ms:.2f} remove_ms={(removed_at - started_at) * 1000:.2f} parse_store_ms={(stored_at - removed_at) * 1000:.2f} publish_ms={(published_at - stored_at) * 1000:.2f} ack_ms={(done_at - published_at) * 1000:.2f}')
                if elapsed_ms > 35.0:
                    self.logger.warning(f'RANGE_SLOW duration_ms={elapsed_ms:.2f}')
                continue
            if tag.startswith('vcmumble.attn.sync.'):
                request_id = tag[len('vcmumble.attn.sync.'):]
                self._remove_player_tag(player, tag)
                self._publish_addon_attenuation_tags(player)
                if request_id:
                    self._add_player_tag(player, f'vcmumble.attn.ack.{request_id}.ok.{self._default_attenuation_level}')
                continue
            if tag.startswith('vcmumble.attn.request.'):
                payload = tag[len('vcmumble.attn.request.'):]
                request_id, _, _ = payload.rpartition('.')
                self._remove_player_tag(player, tag)
                self._publish_addon_attenuation_tags(player)
                if request_id:
                    self._add_player_tag(player, f'vcmumble.attn.ack.{request_id}.ok.{self._default_attenuation_level}')
        return changed

    def _publish_addon_range_tags(self, player: Player, current_range: int | None=None, maximum: int | None=None) -> None:
        _o1 = self._player_key(player)
        _o0 = self._bindings.get(_o1, {})
        _o3 = int(current_range or _o0.get('range') or self._default_range)
        _o2 = int(maximum or (1000 if self._is_operator(player) else self._max_range))
        self._replace_player_tag_prefix(player, 'vcmumble.vr.value.', f'vcmumble.vr.value.{_o3}')
        self._replace_player_tag_prefix(player, 'vcmumble.vr.max.', f'vcmumble.vr.max.{_o2}')

    def _publish_addon_attenuation_tags(self, player: Player) -> None:
        self._replace_player_tag_prefix(player, 'vcmumble.attn.value.', f'vcmumble.attn.value.{self._default_attenuation_level}')

    @staticmethod
    def _replace_player_tag_prefix(player: Player, prefix: str, replacement: str) -> None:
        try:
            tags = set(player.scoreboard_tags)
            for tag in tags:
                if tag.startswith(prefix) and tag != replacement:
                    player.remove_scoreboard_tag(tag)
            if replacement not in set(player.scoreboard_tags):
                player.add_scoreboard_tag(replacement)
        except Exception:
            pass

    @staticmethod
    def _add_player_tag(player: Player, tag: str) -> None:
        try:
            player.add_scoreboard_tag(tag)
        except Exception:
            pass

    @staticmethod
    def _remove_player_tag(player: Player, tag: str) -> None:
        try:
            player.remove_scoreboard_tag(tag)
        except Exception:
            pass

    @staticmethod
    def _is_operator(player: Player) -> bool:
        try:
            return bool(player.is_op)
        except Exception:
            return False

    @staticmethod
    def _voice_enabled_for(player: Player) -> bool:
        try:
            tags = set(player.scoreboard_tags)
            if 'vcmumble.call.mic' in tags:
                return True
            if 'vcmumble.mic.off' in tags:
                return False
            return 'vcmumble.mic.on' in tags
        except Exception:
            return False

    @staticmethod
    def _bounded_int(value: Any, minimum: int, maximum: int, fallback: int) -> int:
        try:
            return max(minimum, min(maximum, int(value)))
        except (TypeError, ValueError):
            return fallback

    @staticmethod
    def _bounded_float(value: Any, minimum: float, maximum: float, fallback: float) -> float:
        try:
            return max(minimum, min(maximum, float(value)))
        except (TypeError, ValueError):
            return fallback
